

from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth.hashers import PBKDF2PasswordHasher
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType

# Create your models here.
class sellerpages(models.Model):
   
        Name=models.CharField(max_length=20)
        Phone=models.CharField(max_length=10)
        Contact_name=models.CharField(max_length=20)
        Region=models.CharField(max_length=20)
        District=models.CharField(max_length=20)
        Email=models.EmailField(max_length=20)
        Image=models.ImageField(upload_to='Uploads/', height_field=None, width_field=None, max_length=None,default=None)
        Product_name=models.CharField(max_length=10)
        Price=models.CharField(max_length=20)
        Status=models.CharField(max_length=20)
        Brand=models.CharField(max_length=20)
        Delivery=models.CharField(max_length=20)
        Description=models.CharField(max_length=20)
        
        
def __str__(self):
        return self.Name
